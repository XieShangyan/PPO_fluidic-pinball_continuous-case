######################################
Writed by Xie Shangyan (Shane) in 801, T6 Buliding,
Harbin Institute of Technology, Shenzhen, China.
TIme: 2022-01-05
######################################

This part is associated with a continuous case about the fluidic pinball control combined with PPO.
It could tame the fluidic pinball in dynamic, means that PPO agent change the roating speeds in a very short time.


Using method:
1-Modify the path to adpate your computer;
2-Load "pinball_uncontinuous.py";  # you can ignore this step in this case because I add it into main.py. #
3-Run "pinball_uncontinuous_main.py".
4-You can change the control timestep and choose state, including velocity, pressure and vorticity.
5-Noted that you need to clear the folder "all_episode" before running a new case, 
and don't delete some important and necessary files, "parameter_list.txt", "state.txt" and other ".txt" files in this floder.


Version:
Python 3.8.2
openFOAM-8
