import numpy as np
import torch

torch.set_default_tensor_type(torch.FloatTensor)


class env:
    def __init__(self):
        # self.a1 = 0      #Cd
        # self.a2 = 0           #Cl
        self.a = np.zeros((1,304))
        self.n_features = 304
        self.step_num = 0
        self.b1 = 0           #转速1
        self.b2 = 0           #转速2
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = self.a
        self.n_actions = 3


    def reset(self):
        # self.a1 = 0
        # self.a2 = 0
        self.a = np.zeros((1,304))
        self.step_num = 0
        self.b1 = 0
        self.b2 = 0
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = [self.a]
        # return np.array([self.a1, self.a2])
        return self.a 
    
    # def adv(self, p, C_d, C_l):
    #     f1 = np.loadtxt('/home/dyfluid/Desktop/front-(0 1 -1)', comments='#', skiprows=1)
    #     C_d = np.mean(f1[11:21,2])
    #     C_l = np.mean(f1[11:21,3])
        
    #     return p, C_d, C_l

    def step(self, action0, action1, action2):
        self.step_num += 1
        f11 = np.loadtxt('./0/postProcessing/forceCoeffs1/' + str(t) + '/forceCoeffs.dat', comments='#', skiprows=1)           #file path must be change in right way
        C_m1 = np.mean(f11[5:10, 1])
        C_d1 = np.mean(f11[5:10, 2])
        C_l1 = np.mean(f11[5:10, 3])
        f12 = np.loadtxt('./0/postProcessing/forceCoeffs2/' + str(t) + '/forceCoeffs.dat', comments='#', skiprows=1)  # file path must be change in right way
        C_m2 = np.mean(f12[5:10, 1])
        C_d2 = np.mean(f12[5:10, 2])
        C_l2 = np.mean(f12[5:10, 3])
        f13 = np.loadtxt('./0/postProcessing/forceCoeffs3/' + str(t) + '/forceCoeffs.dat', comments='#', skiprows=1)  # file path must be change in right way
        C_m3 = np.mean(f13[5:10, 1])
        C_d3 = np.mean(f13[5:10, 2])
        C_l3 = np.mean(f13[5:10, 3])

        C_d_sum = C_d1 + C_d2 + C_d3
        C_l_sum = C_l1 + C_l2 + C_l3

        f14 = np.loadtxt('./parameter_list.txt')
        V1 = f14[0]
        V2 = f14[1]
        V3 = f14[2]
        Ja = C_d_sum / 2
        Jb = - ((V1*C_m1) + (V2*C_m2) + (V3*C_m3)) / 2

        R_func = 3.8 - C_d_sum - 0.2*abs(C_l_sum)


        with open("./mean_coefficient.txt", "a") as f2:
            f2.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("./num_timestep_coefficient.txt", "a") as f3:
            f3.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("./power.txt", "a") as f4:
            f4.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))
        with open("./power_num.txt", "a") as f5:
            f5.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))

       
        s = np.array(self.a, dtype = float)

        # # write pressure as state #
        # f4 = np.loadtxt('/home/caslx/Shane/uncontinuous_case96/testCase/1/postProcessing/probes/0/p', comments='#', skiprows=1)     #file path must be change in right way
        # p_all = f4[31:46,1:154]
        # self.a = np.mean(p_all, 0)

        # write velovity as state #
        directory = "./0/postProcessing/probes/" + str(t-1) + "/U"
        with open(directory, "r") as f:  # 打开文件
            data = f.readlines()  # 读取文件
            data = data[155:]  # 只读取第155行之后的内容
            f = open(directory, "w")  # 以写入的形式打开txt文件
            f.writelines(data)  # 将修改后的文本内容写入
            f.close()  # 关闭文件

        f4 = open("./0/postProcessing/probes/0/U", encoding="utf-8")
        str1 = f4.readline()
        U_all = []
        while str1:
            str_list = str1.split(sep=")")
            str_list = [i.replace("(", "").strip() for i in str_list]
            str_list = str_list[1:-1]
            str_list = [list(map(float, i.split(sep=" ")[:-1])) for i in str_list]
            U_all.append(str_list)
            str1 = f4.readline()
        f4.close()
        U_np = np.array(U_all)
        self.a = np.mean(U_np[5:10], 0)

        with open("./state", "a") as f5:
            f5.seek(0)
            f5.truncate()
            f5.write("{}\n".format(self.a))
        
        s_ = np.array(self.a, dtype=float)

        reward = 0

        reward = 3.8 - C_d_sum - 0.2*abs(C_l_sum)
        done = False
       
        return s_, reward, done, s

    
