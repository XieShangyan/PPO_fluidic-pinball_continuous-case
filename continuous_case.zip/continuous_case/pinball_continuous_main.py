import torch
import torch.nn as nn
from torch.distributions import MultivariateNormal
import numpy as np
# import pinball_continuous
# import matplotlib.pyplot as plt
# import pandas as pd
import os
import time
import shutil

torch.set_default_tensor_type(torch.FloatTensor)
# train_data_split = torch.from_numpy(train_data_split).float()
#device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = torch.device("cpu")
# t = 0


class Env:
    def __init__(self):
        # self.a1 = 0      #Cd
        # self.a2 = 0           #Cl
        self.a = np.zeros((1, 128))
        self.n_features = 128
        self.step_num = 0
        self.b1 = 0           #转速1
        self.b2 = 0           #转速2
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = self.a
        self.n_actions = 3


    def reset(self):
        # self.a1 = 0
        # self.a2 = 0
        self.a = np.zeros((1, 128))
        self.step_num = 0
        self.b1 = 0
        self.b2 = 0
        self.b3 = 0
        self.his_b1 = [self.b1]
        self.his_b2 = [self.b2]
        self.his_b3 = [self.b3]
        # self.his_a1 = [self.a1]
        # self.his_a2 = [self.a2]
        self.his_a = [self.a]
        # return np.array([self.a1, self.a2])
        return self.a 
    
    # def adv(self, p, C_d, C_l):
    #     f1 = np.loadtxt('/home/dyfluid/Desktop/front-(0 1 -1)', comments='#', skiprows=1)
    #     C_d = np.mean(f1[11:21,2])
    #     C_l = np.mean(f1[11:21,3])
        
    #     return p, C_d, C_l

    def step(self, action0, action1, action2):
        global t
        
        self.step_num += 1
        print(t)
        print(self.step_num)
        # f11 = np.loadtxt('./postProcessing/forceCoeffs1/200/forceCoeffs.dat', comments='#', skiprows=1)           #file path must be change in right way
        f11 = np.loadtxt('./postProcessing/forceCoeffs1/' + str(t) + '/forceCoeffs.dat', comments='#')
        # C_m1 = np.mean(f11[5:10, 1])
        # C_d1 = np.mean(f11[5:10, 2])
        # C_l1 = np.mean(f11[5:10, 3])
        C_m1 = f11[1, 1]
        C_d1 = f11[1, 2]
        C_l1 = f11[1, 3]
        f12 = np.loadtxt('./postProcessing/forceCoeffs2/' + str(t) + '/forceCoeffs.dat', comments='#')  # file path must be change in right way
        # C_m2 = np.mean(f12[5:10, 1])
        # C_d2 = np.mean(f12[5:10, 2])
        # C_l2 = np.mean(f12[5:10, 3])
        C_m2 = f12[1, 1]
        C_d2 = f12[1, 2]
        C_l2 = f12[1, 3]
        f13 = np.loadtxt('./postProcessing/forceCoeffs3/' + str(t) + '/forceCoeffs.dat', comments='#')  # file path must be change in right way
        # C_m3 = np.mean(f13[5:10, 1])
        # C_d3 = np.mean(f13[5:10, 2])
        # C_l3 = np.mean(f13[5:10, 3])
        C_m3 = f13[1, 1]
        C_d3 = f13[1, 2]
        C_l3 = f13[1, 3]

        C_d_sum = C_d1 + C_d2 + C_d3
        C_l_sum = C_l1 + C_l2 + C_l3

        f14 = np.loadtxt('./parameter_list.txt')
        V1 = f14[0]
        V2 = f14[1]
        V3 = f14[2]
        Ja = C_d_sum / 2
        Jb = - ((V1*C_m1) + (V2*C_m2) + (V3*C_m3)) / 2

        R_func = 1.9 - (Ja + Jb)


        with open("./mean_coefficient.txt", "a") as f2:
            f2.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("./num_timestep_coefficient.txt", "a") as f3:
            f3.write("{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3, C_l_sum, R_func))
        with open("./power.txt", "a") as f4:
            f4.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))
        with open("./power_num.txt", "a") as f5:
            f5.write("{}   {}   {} \n".format(Ja+Jb, Ja, Jb))

       
        s = np.array(self.a, dtype = float)

        # # write pressure as state #
        # f4 = np.loadtxt('/home/caslx/Shane/continuous_case/testCase/1/postProcessing/probes/0/p', comments='#', skiprows=1)     #file path must be change in right way
        # p_all = f4[31:46,1:154]
        # self.a = np.mean(p_all, 0)

        # write velovity as state #
        directory = "./postProcessing/probes/" + str(t) + "/U"
        with open(directory, "r") as f:
            data = f.readlines()
            data = data[66:]  # if vorticity-input, should line 65 begin
            # data = data[:]
            f = open(directory, "w")
            f.writelines(data)
            f.close()

        f4 = open("./postProcessing/probes/" + str(t) + "/U", encoding="utf-8")
        str1 = f4.readline()
        U_all = []
        while str1:
            str_list = str1.split(sep="(")
            str_list = [i.replace(")", "").strip() for i in str_list]
            str_list = str_list[1:]
            str_list = [list(map(float, i.split(sep=" ")[:-1])) for i in str_list]
            U_all.append(str_list)
            str1 = f4.readline()
        f4.close()
        U_np = np.array(U_all)
        # self.a = np.mean(U_np[5:10], 0)
        self.a = np.mean(U_np[:], 0)

        with open("./state", "a") as f5:
            f5.seek(0)
            f5.truncate()
            f5.write("{}\n".format(self.a))
        
        s_ = np.array(self.a, dtype=float)

        reward = R_func
        done = False
       
        return s_, reward, done, s
class Memory:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []
    
    def clear_memory(self):
        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]

class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, action_std_init):
        super(ActorCritic, self).__init__()

        self.action_dim = action_dim

        # action mean range -1 to 1
        self.actor = nn.Sequential(
                nn.Linear(state_dim, 512),
                nn.Tanh(),
                nn.Linear(512, 128),
                nn.Tanh(),
                nn.Linear(128, action_dim),
                nn.Tanh()
                )
        # critic
        self.critic = nn.Sequential(
                nn.Linear(state_dim, 512),
                nn.Tanh(),
                nn.Linear(512, 128),
                nn.Tanh(),
                nn.Linear(128, 1)
                )
        self.action_var = torch.full((action_dim,), action_std_init*action_std_init).to(device)
       
    def forward(self):
        raise NotImplementedError
    
    def act(self, state, memory):
        action_mean = self.actor(state)
        cov_mat = torch.diag(self.action_var).unsqueeze(dim=0)
        
        dist = MultivariateNormal(action_mean, cov_mat)
        action = dist.sample()
        action_logprob = dist.log_prob(action)
        
        memory.states.append(state)
        memory.actions.append(action)
        memory.logprobs.append(action_logprob)
        
        return action.detach(), action_logprob.detach()
    
    def evaluate(self, state, action):
        action_mean = self.actor(state)
        
        action_var = self.action_var.expand_as(action_mean)
        cov_mat = torch.diag_embed(action_var).to(device)
        
        dist = MultivariateNormal(action_mean, cov_mat)

        if self.action_dim == 1:
            action = action.reshape(-1, self.action_dim)

        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_values = self.critic(state)
        
        return action_logprobs, state_values, dist_entropy

class PPO:
    
    def __init__(self, state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, action_std_init=0.2):
        #self.lr = lr
        #self.betas = betas
        self.action_std = action_std_init
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs
        
        self.policy = ActorCritic(state_dim, action_dim, action_std_init).to(device)
        self.optimizer = torch.optim.Adam([
                        {'params': self.policy.actor.parameters(), 'lr': lr_actor},
                        {'params': self.policy.critic.parameters(), 'lr': lr_critic}
                    ])
        
        self.policy_old = ActorCritic(state_dim, action_dim, action_std_init).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())
        
        self.MseLoss = nn.MSELoss()

    def set_action_std(self, new_action_std):  # update
        self.action_std = new_action_std
        self.policy.set_action_std(new_action_std)
        self.policy_old.set_action_std(new_action_std)

    def decay_action_std(self, action_std_decay_rate, min_action_std):  # update
        self.action_std = self.action_std - action_std_decay_rate
        self.action_std = round(self.action_std, 4)
        if (self.action_std <= min_action_std):
            self.action_std = min_action_std
            print("setting actor output min_action_std to :", self.action_std)
        else:
            print("setting actor output action_std to:", self.action_std)
    
    def select_action(self, state, memory):
        # state = np.concatenate(state, axis=0)
        with torch.no_grad():
            state = state.astype(np.float)
            state = torch.FloatTensor(state.reshape(1, -1)).to(device)
            action, action_logprob = self.policy_old.act(state, memory)
        return action.detach().cpu().numpy().flatten()

    
    def update(self, memory):
        # Monte Carlo estimate of rewards:
        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(memory.rewards), reversed(memory.is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
        
        # Normalizing the rewards:
        rewards = torch.tensor(rewards, dtype=torch.float32).to(device)
        rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-7)
        #rewards = np.repeat(rewards, 2, axis=None)
        
        # convert list to tensor
        old_states = torch.squeeze(torch.stack(memory.states, dim=0)).detach().to(device)
        old_actions = torch.squeeze(torch.stack(memory.actions, dim=0)).detach().to(device)
        old_logprobs = torch.squeeze(torch.stack(memory.logprobs, dim=0)).detach().to(device)
        
        # Optimize policy for K epochs:
        for _ in range(self.K_epochs):
            batch = 5
            for i in range(batch):
                batchSize = len(memory.states) / batch
                startBatchIndex = int(i * batchSize)
                endBatchIndex = int((i+1) * batchSize)
                # Evaluating old actions and values :
                logprobs, state_values, dist_entropy = self.policy.evaluate(old_states[startBatchIndex:endBatchIndex], old_actions[startBatchIndex:endBatchIndex])

                # match state_values tensor dimensions with rewards tensor
                state_values = torch.squeeze(state_values)

                # Finding the ratio (pi_theta / pi_theta__old):
                ratios = torch.exp(logprobs - old_logprobs[startBatchIndex:endBatchIndex].detach())

                # Finding Surrogate Loss:
                advantages = rewards[startBatchIndex:endBatchIndex] - state_values.detach()    #attention the rewards and state_valus must have the same dimention
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages
                # loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, rewards) - 0.01*dist_entropy
                loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, rewards[startBatchIndex:endBatchIndex]) - 0.01*dist_entropy

                # take gradient step
                self.optimizer.zero_grad()
                loss.mean().backward()
                self.optimizer.step()
            
        # Copy new weights into old policy:
        self.policy_old.load_state_dict(self.policy.state_dict())
        
def main():
    ############## Hyperparameters ##############
    env_name = 'pinball_uncontinuous'
    render = False
    #solved_reward = 390         # stop training if running_reward > solved_reward
    #log_interval = 20           # print avg reward in the interval
    max_episodes = 1000        # max training episodes
    max_timesteps = 80       # max timesteps in one episode
    
    update_timestep = 80      # update policy every n timesteps
    
    action_std = 0.2                # constant std for action distribution (Multivariate Normal)
    action_std_decay_rate = 0.005   # linearly decay action_std
    min_action_std = 0.001           # minimum action_std
    action_std_decay_freq = 80       # action_std decay frequency (in num tiomesteps)
    
    K_epochs = 5              # update policy for K epochs
    eps_clip = 0.2              # clip parameter for PPO
    gamma = 0.99                # discount factor
    #lr = 0.0002                 # parameters for Adam optimizer
    #betas = (0.9, 0.999)
    lr_actor = 0.0003
    lr_critic = 0.001
    
    random_seed = 4
    #############################################
    
    # creating environment
    # env = pinball_continuous.env()
    env = Env()
    state_dim = env.n_features
    action_dim = env.n_actions

    # unforced baseline #    
    # with open("/home/caslx/Shane/uncontinuous_case137/parameter_list.txt", "w") as f:
    #     f.write("0 0 0\n")
    #     f.close()
    # for i_episode in range(1, 2):
    #
    #     os.system("/home/caslx/Shane/uncontinuous_case137/run.sh")
    #     dirname = "/home/caslx/Shane/uncontinuous_case137/testCase/1/150"
    #     while not os.path.exists(dirname):
    #         time.sleep(15)
    #         # print('wait')
    #
    #     episode_filename = '/home/caslx/Shane/uncontinuous_case137/all_episode/episode' + str(i_episode)
    #     os.makedirs(episode_filename)
    #     with open("/home/caslx/Shane/uncontinuous_case137/action.txt", "a") as f00:
    #         f00.write("0 0 0\n")
    #
    #     mkpath = episode_filename + '/'
    #     with open(mkpath + 'action_in_episode' + ".txt", "a") as f01:
    #         f01.write("0 0 0\n")
    #
    #     f02 = np.loadtxt(
    #         '/home/caslx/Shane/uncontinuous_case137/testCase/1/postProcessing/forceCoeffs1/0/forceCoeffs.dat',
    #         comments='#', skiprows=1)  # file path must be change in right way
    #     C_d1 = np.mean(f02[120:148, 2])
    #     C_l1 = np.mean(f02[120:148, 3])
    #     f03 = np.loadtxt(
    #         '/home/caslx/Shane/uncontinuous_case137/testCase/1/postProcessing/forceCoeffs2/0/forceCoeffs.dat',
    #         comments='#', skiprows=1)  # file path must be change in right way
    #     C_d2 = np.mean(f03[120:148, 2])
    #     C_l2 = np.mean(f03[120:148, 3])
    #     f04 = np.loadtxt(
    #         '/home/caslx/Shane/uncontinuous_case137/testCase/1/postProcessing/forceCoeffs3/0/forceCoeffs.dat',
    #         comments='#', skiprows=1)  # file path must be change in right way
    #     C_d3 = np.mean(f04[120:148, 2])
    #     C_l3 = np.mean(f04[120:148, 3])
    #     C_d_sum = C_d1 + C_d2 + C_d3
    #     C_l_sum = C_l1 + C_l2 + C_l3
    #     R_func = 3.8 - C_d_sum - 0.2*abs(C_l_sum)
    #     with open("/home/caslx/Shane/uncontinuous_case137/episode_mean.txt", "a") as f05:
    #         f05.write(
    #             "{}   {}   {}   {}   {}    {}    {}    {}    {}\n".format(C_d1, C_d2, C_d3, C_d_sum, C_l1, C_l2, C_l3,
    #                                                                       C_l_sum, R_func))
    #
    #     time.sleep(1)
    #     os.system("/home/caslx/Shane/uncontinuous_case137/remove.sh")
    #     time.sleep(2)

    # os.system("/home/caslx/Shane/uncontinuous_case137/run.sh")
    # dirname = "/home/caslx/Shane/uncontinuous_case137/testCase/1/150"
    # while not os.path.exists(dirname):
    #     time.sleep(15)
    #     print('wait')

    if random_seed:
        print("Random Seed: {}".format(random_seed))
        torch.manual_seed(random_seed)
        #env.seed(random_seed)
        np.random.seed(random_seed)
    
    memory = Memory()

    # initialize a ppo agent
    ppo = PPO(state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip, action_std)

    
    # logging variables
    running_reward = 0
    avg_length = 0
    time_step = 0
    global t
    global i_episode
    # training loop
    for i_episode in range(1, max_episodes+1):
        # state = env.reset()
        running_reward = 0
        episode_filename = './all_episode/episode' + str(i_episode)
        os.makedirs(episode_filename)
        
        f = open('./U_state0', 'r')
        state_list = []
        for line in f:
            line = line.replace("[", "")
            line = line.replace("]", "")
            state_list.append(line.split())
        state = np.array(state_list)
        f.close()
        
        for t in range(200, 280):
            time_step += 1
            # Running policy_old:
            [action0_array, action1_array, action2_array] = ppo.select_action(state, memory)
            action0 = action0_array
            action0 = np.clip(action0, -4, 4)
            action1 = action1_array
            action1 = np.clip(action1, -4, 4)
            action2 = action2_array
            action2 = np.clip(action2, -4, 4)
            with open("./action.txt", "a") as f6:
                f6.write("{} {} {}\n".format(action0, action1, action2))

            #state, reward, done, _ = env.step(action0, action1, action2)

            ### write b1,b2 into "parameter_list.txt" ####

            # time.sleep(1)
            #os.system("/home/caslx/Shane/uncontinuous_case137/remove.sh")

            dirname = "./0/postProcessing"
            while os.path.exists(dirname):
                shutil.rmtree(r"./0/postProcessing")
            #time.sleep(2)
            
            with open("./parameter_list.txt", "a") as f3:
                f3.seek(0)
                f3.truncate()
                f3.write("{} {} {}\n".format(action0, action1, action2))
                #time.sleep(1)
                print('parameter undate successfully')
                

            run(t, i_episode, action0, action1, action2)
            
            # dirname = "./" + str(t)
            # while not os.path.exists(dirname):
            #     time.sleep(2)
            #
            # print('simulation again successfully')
            
            state, reward, done, _ = env.step(action0, action1, action2)
    
            # Saving reward and is_terminals:
            
            memory.rewards.append(reward)
            memory.is_terminals.append(done)

            mkpath = episode_filename + '/'
            with open(mkpath + 'action_in_episode' + ".txt", "a") as f13:
                f13.write("{} {} {}\n".format(action0, action1, action2))
            
            # update if its time
            if time_step % update_timestep == 0:
                print('update')
                ppo.update(memory)
                memory.clear_memory()
                #time_step = 0
                
            running_reward += reward
            
            if time_step % action_std_decay_freq == 0:
                ppo.decay_action_std(action_std_decay_rate, min_action_std)
                
            if render:
                env.render()
            if done:
                break


        with open("./reward.txt", "a") as f12:
            f12.write("{} \n".format(running_reward))

        # record episode mean coefficient and clean the file
        filename = "./mean_coefficient.txt"
        myfile = open(filename)
        shutil.copy(filename, episode_filename)
        n = len(myfile.readlines())
        if n <= 2:
            f7 = np.loadtxt('./mean_coefficient.txt')
            f7 = f7.reshape(1, -1)
            C_d1_episode = f7[0, 0]
            C_d2_episode = f7[0, 1]
            C_d3_episode = f7[0, 2]
            C_d_sum_episode = f7[0, 3]
            C_l1_episode = f7[0, 4]
            C_l2_episode = f7[0, 5]
            C_l3_episode = f7[0, 6]
            C_l_sum_episode = f7[0, 7]
            R_func_episode = f7[0, 8]
            with open("./episode_mean.txt", "a") as f8:
                f8.write("{}    {}    {}    {}    {}    {}    {}    {}    {}\n".format(C_d1_episode, C_d2_episode, C_d3_episode,
                                                                                       C_d_sum_episode, C_l1_episode, C_l2_episode,
                                                                                       C_l3_episode, C_l_sum_episode, R_func_episode))

        else:
            f9 = np.loadtxt('./mean_coefficient.txt')
            C_d1_episode = np.mean(f9[:, 0])
            C_d2_episode = np.mean(f9[:, 1])
            C_d3_episode = np.mean(f9[:, 2])
            C_d_sum_episode = np.mean(f9[:, 3])
            C_l1_episode = np.mean(f9[:, 4])
            C_l2_episode = np.mean(f9[:, 5])
            C_l3_episode = np.mean(f9[:, 6])
            C_l_sum_episode = np.mean(f9[:, 7])
            R_func_episode = np.mean(f9[:, 8])
            with open("./episode_mean.txt", "a") as f10:
                f10.write("{}    {}    {}    {}    {}    {}    {}    {}    {}\n".format(C_d1_episode, C_d2_episode, C_d3_episode,
                                                                                       C_d_sum_episode, C_l1_episode, C_l2_episode,
                                                                                       C_l3_episode, C_l_sum_episode, R_func_episode))

        with open("./mean_coefficient.txt", "a") as f11:
            f11.seek(0)
            f11.truncate()
            f11.close()

        # record episode mean power J and clean the file
        f12 = np.loadtxt('./power.txt')
        J_episode = np.mean(f12[:, 0])
        Ja_episode = np.mean(f12[:, 1])
        Jb_episode = np.mean(f12[:, 2])
        with open("./power_mean.txt", "a") as f13:
            f13.write("{}    {}    {}\n".format(J_episode, Ja_episode, Jb_episode))
        with open("./power.txt", "a") as f14:
            f14.seek(0)
            f14.truncate()
            f14.close()


        #avg_length += t
        
        #if i_episode % 10 == 0 and i_episode >= 20:
        for n in range (200, 281):
            shutil.rmtree(r"./" + str(n))

        shutil.rmtree(r"./postProcessing")

        #copy '200'
        original_folder = '/home/caslx/Shane/RealTimeControl/200'
        target_folder = './200'
        shutil.copytree(original_folder, target_folder)

         #stop training if running_reward > solved_reward
        # if running_reward > (log_interval*solved_reward):
        #     print("########## Solved! ##########")
        #     torch.save(ppo.policy.state_dict(), './PPO_continuous_solved_{}.pth'.format(env_name))
        #     break
        
        # save every 500 episodes
        # if i_episode % 500 == 0:
        #     torch.save(ppo.policy.state_dict(), './PPO_continuous_{}.pth'.format(env_name))
            
        # logging
        # if i_episode % log_interval == 0:
        #     avg_length = int(avg_length/log_interval)
        #     running_reward = int((running_reward/log_interval))
        #     print('Episode {} \t Avg length: {} \t Running reward: {}'.format(i_episode, avg_length, running_reward))
        #     running_reward = 0
        #     avg_length = 0

def run(t, i_episode, action0, action1, action2):
    
    lines = ""
    with open('./U', 'r') as f:
        lines = f.readlines()
        omegaline0 = lines[7]
        omegaline1 = lines[14]
        omegaline2 = lines[23]
        newomegaline0 = omegaline0[:24] + str(action0) + ";\n"
        newomegaline1 = omegaline1[:24] + str(action1) + ";\n"
        newomegaline2 = omegaline2[:24] + str(action2) + ";\n"
        lines[7]  = newomegaline0
        lines[14] = newomegaline1
        lines[23] = newomegaline2
    #print('yes1')
    
    with open('./U', 'w+') as f:
        f.writelines(lines)

    t_min_1_lines = ""
    #print('yes2')
    
    with open('./' + str(t) + '/U', 'r') as f:
        t_min_1_lines = f.readlines()
    #print('yes3')
    
    with open('./' + str(t) + '/U', 'w+') as f:
        f.writelines(t_min_1_lines + lines)
    #print('yes4')
    
    controlDict_lines = ""
    with open('./system/controlDict', 'r') as f:
        controlDict_lines = f.readlines()
    with open('./system/controlDict', 'w+') as f:
        controlDict_lines[19] = controlDict_lines[19][:10] + str(t+1) + ';\n'
        f.writelines(controlDict_lines)
    #print('yes5')
    
    os.system("icoFoam > tmp")
    print('run yes')

if __name__ == '__main__':
    main()
    
